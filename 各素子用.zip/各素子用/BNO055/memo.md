https://akizukidenshi.com/catalog/g/g116996/

U3 FXMA2102 これがライブラリにないかも　気にしなくていい．
テストポイント　

編集→ティアドロップ

ビア直径→JLCPCBの限界

文字の限界サイズ

2cm×1.5cm
